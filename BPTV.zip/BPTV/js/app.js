(function (app) {
    window.app = app || {};
}(window.app));